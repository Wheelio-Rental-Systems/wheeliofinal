import { useState } from "react";
import { Header } from "./components/Header";
import { Hero } from "./components/Hero";
import { VehicleCard, Vehicle } from "./components/VehicleCard";
import { VehicleFilters } from "./components/VehicleFilters";
import { BookingDialog } from "./components/BookingDialog";
import { VehicleDetailsDialog } from "./components/VehicleDetailsDialog";
import { AuthDialog } from "./components/AuthDialog";
import { BecomeHostDialog } from "./components/BecomeHostDialog";
import { indianVehicles } from "./data/vehicles";

function App() {
  const [currentPage, setCurrentPage] = useState("home");
  const [showBookingDialog, setShowBookingDialog] = useState(false);
  const [showDetailsDialog, setShowDetailsDialog] = useState(false);
  const [showAuthDialog, setShowAuthDialog] = useState(false);
  const [showHostDialog, setShowHostDialog] = useState(false);
  const [selectedVehicle, setSelectedVehicle] = useState<Vehicle | null>(null);

  const vehicles: Vehicle[] = indianVehicles;

  const handleBookVehicle = (id: string) => {
    const v = vehicles.find((v) => v.id === id);
    if (v) {
      setSelectedVehicle(v);
      setShowBookingDialog(true);
    }
  };

  const handleViewDetails = (id: string) => {
    const v = vehicles.find((v) => v.id === id);
    if (v) {
      setSelectedVehicle(v);
      setShowDetailsDialog(true);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        onShowAuth={() => setShowAuthDialog(true)}
        onShowHost={() => setShowHostDialog(true)}
      />

      {/* HOME */}
      {currentPage === "home" && <Hero onSearch={() => setCurrentPage("vehicles")} />}

      {/* VEHICLES PAGE */}
      {currentPage === "vehicles" && (
        <section className="container px-4 py-8">
          <h1 className="text-3xl mb-2 bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
            Available Vehicles
          </h1>
          <p className="text-muted-foreground mb-6">
            Find the perfect ride for your journey
          </p>

          {/* ✅ FIXED ALIGNMENT */}
          <div className="flex gap-6">
            {/* FILTER */}
            <VehicleFilters />

            {/* VEHICLE GRID */}
            <div className="flex-1">
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
                {vehicles.map((vehicle) => (
                  <VehicleCard
                    key={vehicle.id}
                    vehicle={vehicle}
                    onBook={handleBookVehicle}
                    onViewDetails={handleViewDetails}
                  />
                ))}
              </div>
            </div>
          </div>
        </section>
      )}

      {/* DIALOGS */}
      <BookingDialog
        open={showBookingDialog}
        onOpenChange={setShowBookingDialog}
        vehicle={selectedVehicle}
      />

      <VehicleDetailsDialog
        open={showDetailsDialog}
        onOpenChange={setShowDetailsDialog}
        vehicle={selectedVehicle}
        onBook={() => {
          setShowDetailsDialog(false);
          if (selectedVehicle) handleBookVehicle(selectedVehicle.id);
        }}
      />

      <AuthDialog open={showAuthDialog} onOpenChange={setShowAuthDialog} />
      <BecomeHostDialog open={showHostDialog} onOpenChange={setShowHostDialog} />
    </div>
  );
}

export default App;
