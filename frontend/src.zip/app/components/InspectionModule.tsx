import { Camera, CheckCircle, XCircle, Upload, AlertTriangle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Checkbox } from "./ui/checkbox";
import { Textarea } from "./ui/textarea";
import { Badge } from "./ui/badge";
import { useState } from "react";

export function InspectionModule() {
  const [checklist, setChecklist] = useState([
    { id: 1, item: 'Exterior Body Condition', checked: false },
    { id: 2, item: 'Tire Condition & Pressure', checked: false },
    { id: 3, item: 'Lights & Indicators', checked: false },
    { id: 4, item: 'Interior Cleanliness', checked: false },
    { id: 5, item: 'Fuel Level', checked: false },
    { id: 6, item: 'Dashboard Warning Lights', checked: false },
    { id: 7, item: 'Brake Functionality', checked: false },
    { id: 8, item: 'Mirror Condition', checked: false },
  ]);

  const pendingInspections = [
    {
      id: 1,
      vehicle: 'Tesla Model 3',
      bookingId: 'BK-2026-0015',
      customer: 'Sarah Johnson',
      returnDate: '2026-01-03',
      status: 'pending',
    },
    {
      id: 2,
      vehicle: 'BMW X5',
      bookingId: 'BK-2026-0018',
      customer: 'Mike Chen',
      returnDate: '2026-01-03',
      status: 'in-progress',
    },
  ];

  const handleChecklistToggle = (id: number) => {
    setChecklist(checklist.map(item => 
      item.id === id ? { ...item, checked: !item.checked } : item
    ));
  };

  return (
    <div className="container px-4 py-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl mb-2 bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
          Vehicle Inspection
        </h1>
        <p className="text-muted-foreground">Inspect returned vehicles and report damages</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Pending Inspections */}
        <Card className="border-primary/20 lg:col-span-1">
          <CardHeader>
            <CardTitle>Pending Inspections</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            {pendingInspections.map((inspection) => (
              <div
                key={inspection.id}
                className="p-4 rounded-lg bg-muted/50 space-y-2 cursor-pointer hover:bg-muted transition-colors"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <h4 className="text-sm">{inspection.vehicle}</h4>
                    <p className="text-xs text-muted-foreground">{inspection.bookingId}</p>
                  </div>
                  <Badge
                    className={
                      inspection.status === 'pending'
                        ? 'bg-[#f59e0b]/20 text-[#f59e0b] border-[#f59e0b]/30'
                        : 'bg-[#06b6d4]/20 text-[#06b6d4] border-[#06b6d4]/30'
                    }
                  >
                    {inspection.status}
                  </Badge>
                </div>
                <div className="text-xs text-muted-foreground">
                  <div>Customer: {inspection.customer}</div>
                  <div>Returned: {inspection.returnDate}</div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* Inspection Form */}
        <div className="lg:col-span-2 space-y-6">
          {/* Current Inspection */}
          <Card className="border-primary/20">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div>
                  <CardTitle>BMW X5 - BK-2026-0018</CardTitle>
                  <p className="text-sm text-muted-foreground mt-1">Customer: Mike Chen</p>
                </div>
                <Badge className="bg-[#06b6d4]/20 text-[#06b6d4] border-[#06b6d4]/30">
                  In Progress
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              {/* Checklist */}
              <div className="space-y-3">
                <h4>Inspection Checklist</h4>
                <div className="space-y-3">
                  {checklist.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center space-x-3 p-3 rounded-lg bg-muted/50"
                    >
                      <Checkbox
                        id={`check-${item.id}`}
                        checked={item.checked}
                        onCheckedChange={() => handleChecklistToggle(item.id)}
                      />
                      <label
                        htmlFor={`check-${item.id}`}
                        className={`flex-1 cursor-pointer ${
                          item.checked ? 'text-muted-foreground line-through' : ''
                        }`}
                      >
                        {item.item}
                      </label>
                      {item.checked && (
                        <CheckCircle className="h-5 w-5 text-[#10b981]" />
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Damage Report */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <AlertTriangle className="h-5 w-5 text-[#f59e0b]" />
                  <h4>Damage Report</h4>
                </div>
                <Textarea
                  placeholder="Describe any damages, scratches, or issues found during inspection..."
                  className="min-h-[100px]"
                />
              </div>

              {/* Image Upload */}
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <Camera className="h-5 w-5 text-primary" />
                  <h4>Upload Images</h4>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  <div className="aspect-square rounded-lg bg-muted/50 border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted transition-colors">
                    <Upload className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <div className="aspect-square rounded-lg bg-muted/50 border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted transition-colors">
                    <Upload className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <div className="aspect-square rounded-lg bg-muted/50 border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted transition-colors">
                    <Upload className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <div className="aspect-square rounded-lg bg-muted/50 border-2 border-dashed border-border flex items-center justify-center cursor-pointer hover:bg-muted transition-colors">
                    <Upload className="h-8 w-8 text-muted-foreground" />
                  </div>
                </div>
              </div>

              {/* Penalty Calculation */}
              <Card className="bg-muted/30">
                <CardContent className="p-4 space-y-3">
                  <h4>Security Deposit & Penalties</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Security Deposit</span>
                      <span>$500.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Damage Penalty</span>
                      <span className="text-destructive">-$150.00</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Late Return Fee</span>
                      <span className="text-destructive">-$50.00</span>
                    </div>
                    <div className="border-t border-border pt-2 flex justify-between">
                      <span>Refund Amount</span>
                      <span className="text-xl bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
                        $300.00
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Actions */}
              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  className="flex-1"
                >
                  <XCircle className="mr-2 h-4 w-4" />
                  Reject Refund
                </Button>
                <Button
                  className="flex-1 bg-gradient-to-r from-[#7c3aed] to-[#ec4899] hover:opacity-90"
                >
                  <CheckCircle className="mr-2 h-4 w-4" />
                  Approve & Complete
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
