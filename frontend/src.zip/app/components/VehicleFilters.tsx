import { useState } from "react";
import { Search } from "lucide-react";

/* -------------------- TYPES -------------------- */
export interface VehicleFilterState {
  search: string;
  type: "all" | "car" | "bike";
  category: string;
  brand: string;
  seating: number;
  distance: number;
  maxPrice: number;
  rating: number;
}

/* -------------------- CONSTANTS -------------------- */
const CAR_CATEGORIES = ["Hatchback", "Sedan", "SUV"];
const BIKE_CATEGORIES = ["Scooter", "Commuter", "Sports", "Cruiser"];

const CAR_BRANDS = [
  "Maruti Suzuki",
  "Tata",
  "Mahindra",
  "Hyundai",
  "Kia",
  "Toyota",
  "Honda",
  "Skoda",
  "Volkswagen",
  "Renault",
  "Nissan",
];

const BIKE_BRANDS = [
  "Hero",
  "Bajaj",
  "TVS",
  "Royal Enfield",
  "Honda",
  "Suzuki",
  "Yamaha",
  "KTM",
  "Jawa",
];

const MAX_PRICE = 5000;
const inr = (v: number) => `₹${v}`;

/* -------------------- COMPONENT -------------------- */
export function VehicleFilters({
  onApply,
}: {
  onApply?: (filters: VehicleFilterState) => void;
}) {
  const [filters, setFilters] = useState<VehicleFilterState>({
    search: "",
    type: "all",
    category: "all",
    brand: "all",
    seating: 0,
    distance: 10,
    maxPrice: MAX_PRICE,
    rating: 0,
  });

  const brands =
    filters.type === "bike"
      ? BIKE_BRANDS
      : filters.type === "car"
      ? CAR_BRANDS
      : [...CAR_BRANDS, ...BIKE_BRANDS];

  const categories =
    filters.type === "bike"
      ? BIKE_CATEGORIES
      : filters.type === "car"
      ? CAR_CATEGORIES
      : [...CAR_CATEGORIES, ...BIKE_CATEGORIES];

  return (
    <aside className="w-72 sticky top-20 h-fit p-5 rounded-xl bg-[#0f0f1a] border border-white/10 space-y-5">
      {/* SEARCH */}
      <div>
        <label className="text-sm text-gray-300">Search</label>
        <div className="relative mt-1">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <input
            placeholder="Search vehicles..."
            value={filters.search}
            onChange={(e) =>
              setFilters({ ...filters, search: e.target.value })
            }
            className="w-full pl-10 py-2 rounded-lg bg-[#161625] border border-white/10 text-white"
          />
        </div>
      </div>

      {/* TYPE */}
      <div>
        <label className="text-sm text-gray-300">Type</label>
        <select
          value={filters.type}
          onChange={(e) =>
            setFilters({
              ...filters,
              type: e.target.value as any,
              category: "all",
              brand: "all",
            })
          }
          className="w-full mt-1 px-3 py-2 rounded-lg bg-[#161625] text-white"
        >
          <option value="all">All</option>
          <option value="car">Car</option>
          <option value="bike">Bike / Scooter</option>
        </select>
      </div>

      {/* CATEGORY */}
      <div>
        <label className="text-sm text-gray-300">Category</label>
        <select
          value={filters.category}
          onChange={(e) =>
            setFilters({ ...filters, category: e.target.value })
          }
          className="w-full mt-1 px-3 py-2 rounded-lg bg-[#161625] text-white"
        >
          <option value="all">All Categories</option>
          {categories.map((c) => (
            <option key={c} value={c.toLowerCase()}>
              {c}
            </option>
          ))}
        </select>
      </div>

      {/* BRAND (MERGED) */}
      <div>
        <label className="text-sm text-gray-300">Brand</label>
        <select
          value={filters.brand}
          onChange={(e) =>
            setFilters({ ...filters, brand: e.target.value })
          }
          className="w-full mt-1 px-3 py-2 rounded-lg bg-[#161625] text-white"
        >
          <option value="all">All Brands</option>
          {brands.map((b) => (
            <option key={b} value={b}>
              {b}
            </option>
          ))}
        </select>
      </div>

      {/* SEATING (CARS ONLY) */}
      <div>
        <label className="text-sm text-gray-300">Seating Capacity</label>
        <select
          value={filters.seating}
          onChange={(e) =>
            setFilters({ ...filters, seating: Number(e.target.value) })
          }
          disabled={filters.type === "bike"}
          className="w-full mt-1 px-3 py-2 rounded-lg bg-[#161625] text-white disabled:opacity-40"
        >
          <option value={0}>Any</option>
          <option value={2}>2 Seater</option>
          <option value={4}>4 Seater</option>
          <option value={5}>5 Seater</option>
          <option value={7}>7 Seater</option>
        </select>
      </div>

      {/* DISTANCE */}
      <div>
        <label className="text-sm text-gray-300">
          Distance (within {filters.distance} km)
        </label>
        <input
          type="range"
          min={1}
          max={50}
          value={filters.distance}
          onChange={(e) =>
            setFilters({ ...filters, distance: Number(e.target.value) })
          }
          className="w-full accent-purple-500"
        />
      </div>

      {/* PRICE */}
      <div>
        <label className="text-sm text-gray-300">Price (per day)</label>
        <input
          type="range"
          min={0}
          max={MAX_PRICE}
          step={100}
          value={filters.maxPrice}
          onChange={(e) =>
            setFilters({ ...filters, maxPrice: Number(e.target.value) })
          }
          className="w-full accent-purple-500"
        />
        <div className="flex justify-between text-xs text-gray-400">
          <span>{inr(0)}</span>
          <span>{inr(filters.maxPrice)}+</span>
        </div>
      </div>

      {/* RATING (MERGED) */}
      <div>
        <label className="text-sm text-gray-300">Rating</label>
        <select
          value={filters.rating}
          onChange={(e) =>
            setFilters({ ...filters, rating: Number(e.target.value) })
          }
          className="w-full mt-1 px-3 py-2 rounded-lg bg-[#161625] text-white"
        >
          <option value={0}>All Ratings</option>
          <option value={4}>4★ & above</option>
          <option value={3}>3★ & above</option>
        </select>
      </div>

      {/* APPLY */}
      <button
        onClick={() => onApply?.(filters)}
        className="w-full py-2 mt-2 rounded-lg font-semibold bg-gradient-to-r from-purple-600 to-pink-500"
      >
        Apply Filters
      </button>
    </aside>
  );
}
