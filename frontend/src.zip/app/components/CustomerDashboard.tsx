import { Calendar, Clock, FileText, Upload, AlertCircle, CheckCircle, XCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";

export function CustomerDashboard() {
  const activeBookings = [
    {
      id: '1',
      vehicle: 'Tesla Model 3',
      startDate: '2026-01-05',
      endDate: '2026-01-10',
      status: 'active',
      progress: 60,
      pickupLocation: 'Downtown Center',
      totalCost: 750
    },
    {
      id: '2',
      vehicle: 'BMW X5',
      startDate: '2026-01-15',
      endDate: '2026-01-20',
      status: 'upcoming',
      progress: 0,
      pickupLocation: 'Airport Terminal',
      totalCost: 900
    }
  ];

  const pastBookings = [
    {
      id: '3',
      vehicle: 'Mercedes-Benz C-Class',
      startDate: '2025-12-20',
      endDate: '2025-12-25',
      status: 'completed',
      totalCost: 800,
      rating: 5
    },
    {
      id: '4',
      vehicle: 'Harley-Davidson Street 750',
      startDate: '2025-11-10',
      endDate: '2025-11-15',
      status: 'completed',
      totalCost: 450,
      rating: 5
    }
  ];

  const documents = [
    { name: 'Driving License', status: 'verified', uploadDate: '2025-12-01' },
    { name: 'ID Proof', status: 'verified', uploadDate: '2025-12-01' },
    { name: 'Address Proof', status: 'pending', uploadDate: '2025-12-30' }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active':
        return 'bg-[#10b981]/20 text-[#10b981] border-[#10b981]/30';
      case 'upcoming':
        return 'bg-[#06b6d4]/20 text-[#06b6d4] border-[#06b6d4]/30';
      case 'completed':
        return 'bg-muted text-muted-foreground border-border';
      default:
        return 'bg-muted text-muted-foreground border-border';
    }
  };

  const getDocumentIcon = (status: string) => {
    switch (status) {
      case 'verified':
        return <CheckCircle className="h-5 w-5 text-[#10b981]" />;
      case 'pending':
        return <Clock className="h-5 w-5 text-[#f59e0b]" />;
      case 'rejected':
        return <XCircle className="h-5 w-5 text-destructive" />;
      default:
        return <AlertCircle className="h-5 w-5 text-muted-foreground" />;
    }
  };

  return (
    <div className="container px-4 py-8 space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl mb-2 bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
          My Dashboard
        </h1>
        <p className="text-muted-foreground">Manage your bookings and documents</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="border-primary/20 bg-gradient-to-br from-[#7c3aed]/10 to-transparent">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground">Active Bookings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">1</div>
          </CardContent>
        </Card>

        <Card className="border-primary/20 bg-gradient-to-br from-[#ec4899]/10 to-transparent">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground">Upcoming</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">1</div>
          </CardContent>
        </Card>

        <Card className="border-primary/20 bg-gradient-to-br from-[#06b6d4]/10 to-transparent">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground">Total Trips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">24</div>
          </CardContent>
        </Card>

        <Card className="border-primary/20 bg-gradient-to-br from-[#10b981]/10 to-transparent">
          <CardHeader className="pb-3">
            <CardTitle className="text-sm text-muted-foreground">Total Spent</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">$12.5K</div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="bookings" className="space-y-4">
        <TabsList className="grid w-full md:w-auto md:inline-grid grid-cols-3">
          <TabsTrigger value="bookings">Bookings</TabsTrigger>
          <TabsTrigger value="documents">Documents</TabsTrigger>
          <TabsTrigger value="history">History</TabsTrigger>
        </TabsList>

        {/* Active Bookings */}
        <TabsContent value="bookings" className="space-y-4">
          {activeBookings.map((booking) => (
            <Card key={booking.id} className="border-primary/20">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle>{booking.vehicle}</CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      {booking.pickupLocation}
                    </p>
                  </div>
                  <Badge className={getStatusColor(booking.status)}>
                    {booking.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{booking.startDate}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-muted-foreground" />
                    <span>{booking.endDate}</span>
                  </div>
                </div>

                {booking.status === 'active' && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Trip Progress</span>
                      <span>{booking.progress}%</span>
                    </div>
                    <Progress value={booking.progress} className="h-2" />
                  </div>
                )}

                <div className="flex items-center justify-between pt-2 border-t border-border/40">
                  <div>
                    <span className="text-sm text-muted-foreground">Total Cost</span>
                    <div className="text-xl bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
                      ${booking.totalCost}
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button variant="outline" size="sm">
                      <FileText className="mr-2 h-4 w-4" />
                      Invoice
                    </Button>
                    {booking.status === 'active' && (
                      <Button size="sm" className="bg-gradient-to-r from-[#7c3aed] to-[#ec4899]">
                        Extend
                      </Button>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        {/* Documents */}
        <TabsContent value="documents" className="space-y-4">
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle>Uploaded Documents</CardTitle>
              <p className="text-sm text-muted-foreground">
                Keep your documents up to date for seamless bookings
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              {documents.map((doc, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-4 rounded-lg bg-muted/50"
                >
                  <div className="flex items-center gap-3">
                    {getDocumentIcon(doc.status)}
                    <div>
                      <div className="font-medium">{doc.name}</div>
                      <div className="text-sm text-muted-foreground">
                        Uploaded on {doc.uploadDate}
                      </div>
                    </div>
                  </div>
                  <Badge
                    className={
                      doc.status === 'verified'
                        ? 'bg-[#10b981]/20 text-[#10b981] border-[#10b981]/30'
                        : 'bg-[#f59e0b]/20 text-[#f59e0b] border-[#f59e0b]/30'
                    }
                  >
                    {doc.status}
                  </Badge>
                </div>
              ))}

              <Button className="w-full bg-gradient-to-r from-[#7c3aed] to-[#ec4899] hover:opacity-90">
                <Upload className="mr-2 h-4 w-4" />
                Upload New Document
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* History */}
        <TabsContent value="history" className="space-y-4">
          {pastBookings.map((booking) => (
            <Card key={booking.id} className="border-primary/20">
              <CardContent className="p-6">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <h4>{booking.vehicle}</h4>
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <span>{booking.startDate}</span>
                      <span>→</span>
                      <span>{booking.endDate}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xl bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
                      ${booking.totalCost}
                    </div>
                    <Button variant="ghost" size="sm" className="mt-2">
                      View Details
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}
