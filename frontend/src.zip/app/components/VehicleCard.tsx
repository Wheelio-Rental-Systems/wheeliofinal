import { Users, Gauge, Fuel, Star, MapPin } from "lucide-react";
import { Card, CardContent, CardFooter } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { ImageWithFallback } from "./figma/ImageWithFallback";

export interface Vehicle {
  id: string;
  name: string;
  brand: string;
  type: "car" | "bike";
  category?: string;
  image: string;
  pricePerDay: number;
  rating: number;
  seats?: number;
  transmission: string;
  fuelType: string;
  status: "available" | "rented" | "maintenance";
  distance?: number;
}

export function VehicleCard({
  vehicle,
  onBook,
  onViewDetails,
}: {
  vehicle: Vehicle;
  onBook: (id: string) => void;
  onViewDetails: (id: string) => void;
}) {
  return (
    <Card className="group overflow-hidden border-primary/20 hover:border-primary/40 transition">
      {/* IMAGE */}
      <div className="relative h-48">
        <ImageWithFallback
          src={vehicle.image}
          alt={vehicle.name}
          className="w-full h-full object-cover group-hover:scale-110 transition"
        />

        {vehicle.category && (
          <Badge className="absolute top-3 left-3 bg-background/80">
            {vehicle.category.toUpperCase()}
          </Badge>
        )}

        <div className="absolute bottom-3 left-3 flex items-center gap-1 bg-background/80 px-2 py-1 rounded-full">
          <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
          <span className="text-sm">{vehicle.rating}</span>
        </div>
      </div>

      <CardContent className="p-4 space-y-2">
        <h3>{vehicle.name}</h3>
        <p className="text-sm text-muted-foreground">{vehicle.brand}</p>

        <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
          {vehicle.seats && (
            <span className="flex items-center gap-1">
              <Users className="h-4 w-4" /> {vehicle.seats}
            </span>
          )}
          <span className="flex items-center gap-1">
            <Gauge className="h-4 w-4" /> {vehicle.transmission}
          </span>
          <span className="flex items-center gap-1">
            <Fuel className="h-4 w-4" /> {vehicle.fuelType}
          </span>
        </div>

        {vehicle.distance && (
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <MapPin className="h-3 w-3" />
            {vehicle.distance} km away
          </div>
        )}

        <div className="text-xl text-primary">
          ₹{vehicle.pricePerDay}
          <span className="text-sm text-muted-foreground"> /day</span>
        </div>
      </CardContent>

      <CardFooter className="p-4 pt-0 flex gap-2">
        <Button variant="outline" className="flex-1" onClick={() => onViewDetails(vehicle.id)}>
          Details
        </Button>
        <Button
          className="flex-1 bg-gradient-to-r from-purple-600 to-pink-500"
          onClick={() => onBook(vehicle.id)}
          disabled={vehicle.status !== "available"}
        >
          Book Now
        </Button>
      </CardFooter>
    </Card>
  );
}
