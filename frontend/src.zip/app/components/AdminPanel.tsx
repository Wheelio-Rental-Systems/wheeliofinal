import { Plus, TrendingUp, Car, Users, DollarSign, Wrench } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Badge } from "./ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from "recharts";

export function AdminPanel() {
  const revenueData = [
    { month: 'Jan', revenue: 45000 },
    { month: 'Feb', revenue: 52000 },
    { month: 'Mar', revenue: 48000 },
    { month: 'Apr', revenue: 61000 },
    { month: 'May', revenue: 55000 },
    { month: 'Jun', revenue: 67000 },
  ];

  const utilizationData = [
    { month: 'Jan', rate: 78 },
    { month: 'Feb', rate: 82 },
    { month: 'Mar', rate: 75 },
    { month: 'Apr', rate: 88 },
    { month: 'May', rate: 85 },
    { month: 'Jun', rate: 92 },
  ];

  const vehicles = [
    { id: 1, name: 'Tesla Model 3', status: 'available', revenue: 12500, utilization: 95 },
    { id: 2, name: 'BMW X5', status: 'rented', revenue: 15200, utilization: 88 },
    { id: 3, name: 'Mercedes-Benz C-Class', status: 'available', revenue: 14800, utilization: 90 },
    { id: 4, name: 'Audi A4', status: 'maintenance', revenue: 8900, utilization: 65 },
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'available':
        return 'bg-[#10b981]/20 text-[#10b981] border-[#10b981]/30';
      case 'rented':
        return 'bg-[#f59e0b]/20 text-[#f59e0b] border-[#f59e0b]/30';
      case 'maintenance':
        return 'bg-destructive/20 text-destructive border-destructive/30';
      default:
        return 'bg-muted text-muted-foreground border-border';
    }
  };

  return (
    <div className="container px-4 py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2 bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
            Admin Panel
          </h1>
          <p className="text-muted-foreground">Manage your fleet and monitor performance</p>
        </div>
        <Button className="bg-gradient-to-r from-[#7c3aed] to-[#ec4899] hover:opacity-90">
          <Plus className="mr-2 h-4 w-4" />
          Add Vehicle
        </Button>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="border-primary/20 bg-gradient-to-br from-[#7c3aed]/10 to-transparent">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm text-muted-foreground">Total Revenue</CardTitle>
              <DollarSign className="h-4 w-4 text-[#7c3aed]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">$67,000</div>
            <div className="flex items-center gap-1 text-sm text-[#10b981] mt-2">
              <TrendingUp className="h-4 w-4" />
              <span>+12.5%</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-primary/20 bg-gradient-to-br from-[#ec4899]/10 to-transparent">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm text-muted-foreground">Total Vehicles</CardTitle>
              <Car className="h-4 w-4 text-[#ec4899]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">247</div>
            <div className="flex items-center gap-1 text-sm text-muted-foreground mt-2">
              <span>185 Active</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-primary/20 bg-gradient-to-br from-[#06b6d4]/10 to-transparent">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm text-muted-foreground">Active Users</CardTitle>
              <Users className="h-4 w-4 text-[#06b6d4]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">1,284</div>
            <div className="flex items-center gap-1 text-sm text-[#10b981] mt-2">
              <TrendingUp className="h-4 w-4" />
              <span>+8.2%</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-primary/20 bg-gradient-to-br from-[#10b981]/10 to-transparent">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm text-muted-foreground">Utilization</CardTitle>
              <TrendingUp className="h-4 w-4 text-[#10b981]" />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-3xl">92%</div>
            <div className="flex items-center gap-1 text-sm text-[#10b981] mt-2">
              <TrendingUp className="h-4 w-4" />
              <span>+5.1%</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="analytics" className="space-y-4">
        <TabsList className="grid w-full md:w-auto md:inline-grid grid-cols-3">
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="fleet">Fleet Management</TabsTrigger>
          <TabsTrigger value="pricing">Pricing</TabsTrigger>
        </TabsList>

        {/* Analytics */}
        <TabsContent value="analytics" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle>Revenue Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={revenueData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3e" />
                    <XAxis dataKey="month" stroke="#a8a8b8" />
                    <YAxis stroke="#a8a8b8" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#16161f',
                        border: '1px solid rgba(124, 58, 237, 0.2)',
                        borderRadius: '8px',
                      }}
                    />
                    <Bar dataKey="revenue" fill="url(#colorRevenue)" radius={[8, 8, 0, 0]} />
                    <defs>
                      <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="0%" stopColor="#7c3aed" />
                        <stop offset="100%" stopColor="#ec4899" />
                      </linearGradient>
                    </defs>
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-primary/20">
              <CardHeader>
                <CardTitle>Utilization Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <LineChart data={utilizationData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#2a2a3e" />
                    <XAxis dataKey="month" stroke="#a8a8b8" />
                    <YAxis stroke="#a8a8b8" />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: '#16161f',
                        border: '1px solid rgba(124, 58, 237, 0.2)',
                        borderRadius: '8px',
                      }}
                    />
                    <Line
                      type="monotone"
                      dataKey="rate"
                      stroke="#10b981"
                      strokeWidth={3}
                      dot={{ fill: '#10b981', r: 6 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Fleet Management */}
        <TabsContent value="fleet" className="space-y-4">
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle>Vehicle Inventory</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Revenue (MTD)</TableHead>
                    <TableHead>Utilization</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {vehicles.map((vehicle) => (
                    <TableRow key={vehicle.id}>
                      <TableCell>{vehicle.name}</TableCell>
                      <TableCell>
                        <Badge className={getStatusColor(vehicle.status)}>
                          {vehicle.status}
                        </Badge>
                      </TableCell>
                      <TableCell>${vehicle.revenue.toLocaleString()}</TableCell>
                      <TableCell>{vehicle.utilization}%</TableCell>
                      <TableCell>
                        <div className="flex gap-2">
                          <Button variant="ghost" size="sm">Edit</Button>
                          <Button variant="ghost" size="sm">
                            <Wrench className="h-4 w-4" />
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pricing */}
        <TabsContent value="pricing" className="space-y-4">
          <Card className="border-primary/20">
            <CardHeader>
              <CardTitle>Dynamic Pricing Rules</CardTitle>
              <p className="text-sm text-muted-foreground">
                Manage pricing for different periods and events
              </p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="p-4 rounded-lg bg-muted/50 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4>Weekend Premium</h4>
                    <p className="text-sm text-muted-foreground">Friday - Sunday</p>
                  </div>
                  <Badge className="bg-[#7c3aed]/20 text-[#7c3aed] border-[#7c3aed]/30">
                    +20%
                  </Badge>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-muted/50 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4>Holiday Season</h4>
                    <p className="text-sm text-muted-foreground">Dec 20 - Jan 5</p>
                  </div>
                  <Badge className="bg-[#ec4899]/20 text-[#ec4899] border-[#ec4899]/30">
                    +35%
                  </Badge>
                </div>
              </div>

              <div className="p-4 rounded-lg bg-muted/50 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <h4>Long-term Rental</h4>
                    <p className="text-sm text-muted-foreground">7+ days</p>
                  </div>
                  <Badge className="bg-[#10b981]/20 text-[#10b981] border-[#10b981]/30">
                    -15%
                  </Badge>
                </div>
              </div>

              <Button className="w-full bg-gradient-to-r from-[#7c3aed] to-[#ec4899] hover:opacity-90">
                <Plus className="mr-2 h-4 w-4" />
                Add New Rule
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
