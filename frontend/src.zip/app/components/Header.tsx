import { Car, Menu, Bell, User, LogOut, LogIn, Home as HomeIcon } from "lucide-react";
import { Button } from "./ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "./ui/dropdown-menu";
import { Badge } from "./ui/badge";

interface HeaderProps {
  onNavigate: (page: string) => void;
  currentPage: string;
  userRole: 'customer' | 'staff' | 'admin';
  isLoggedIn?: boolean;
  onShowAuth?: () => void;
  onShowHost?: () => void;
}

export function Header({ onNavigate, currentPage, userRole, isLoggedIn = false, onShowAuth, onShowHost }: HeaderProps) {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between px-4">
        {/* Logo */}
        <div className="flex items-center gap-2 cursor-pointer" onClick={() => onNavigate('home')}>
          <div className="relative">
            <div className="absolute inset-0 bg-gradient-to-r from-[#7c3aed] to-[#ec4899] rounded-lg blur opacity-75"></div>
            <div className="relative bg-gradient-to-r from-[#7c3aed] to-[#ec4899] p-2 rounded-lg">
              <Car className="h-6 w-6 text-white" />
            </div>
          </div>
          <span className="text-xl bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
            Wheelio
          </span>
        </div>

        {/* Navigation */}
        <nav className="hidden md:flex items-center gap-6">
          <button
            onClick={() => onNavigate('home')}
            className={`transition-colors hover:text-primary ${
              currentPage === 'home' ? 'text-primary' : 'text-muted-foreground'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => onNavigate('vehicles')}
            className={`transition-colors hover:text-primary ${
              currentPage === 'vehicles' ? 'text-primary' : 'text-muted-foreground'
            }`}
          >
            Vehicles
          </button>
          {isLoggedIn && userRole === 'customer' && (
            <button
              onClick={() => onNavigate('dashboard')}
              className={`transition-colors hover:text-primary ${
                currentPage === 'dashboard' ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              My Bookings
            </button>
          )}
          {isLoggedIn && userRole === 'admin' && (
            <button
              onClick={() => onNavigate('admin')}
              className={`transition-colors hover:text-primary ${
                currentPage === 'admin' ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              Admin Panel
            </button>
          )}
          {isLoggedIn && userRole === 'staff' && (
            <button
              onClick={() => onNavigate('inspection')}
              className={`transition-colors hover:text-primary ${
                currentPage === 'inspection' ? 'text-primary' : 'text-muted-foreground'
              }`}
            >
              Inspections
            </button>
          )}
        </nav>

        {/* Actions */}
        <div className="flex items-center gap-3">
          {!isLoggedIn ? (
            <>
              <Button
                variant="outline"
                onClick={onShowHost}
                className="hidden sm:flex"
              >
                <HomeIcon className="h-4 w-4 mr-2" />
                Become a Host
              </Button>
              <Button
                onClick={onShowAuth}
                className="bg-gradient-to-r from-[#7c3aed] to-[#ec4899] hover:opacity-90"
              >
                <LogIn className="h-4 w-4 mr-2" />
                Login
              </Button>
            </>
          ) : (
            <>
              <Button
                variant="ghost"
                size="icon"
                className="relative"
                onClick={() => onNavigate('notifications')}
              >
                <Bell className="h-5 w-5" />
                <span className="absolute top-1 right-1 h-2 w-2 bg-accent rounded-full"></span>
              </Button>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>
                    <div className="flex flex-col space-y-1">
                      <p>John Doe</p>
                      <p className="text-xs text-muted-foreground">
                        john.doe@wheelio.com
                      </p>
                      <Badge className="w-fit mt-1 bg-primary/20 text-primary hover:bg-primary/30">
                        {userRole.charAt(0).toUpperCase() + userRole.slice(1)}
                      </Badge>
                    </div>
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => onNavigate('profile')}>
                    <User className="mr-2 h-4 w-4" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={onShowHost}>
                    <HomeIcon className="mr-2 h-4 w-4" />
                    Become a Host
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => window.location.reload()}>
                    <LogOut className="mr-2 h-4 w-4" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </>
          )}

          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
          >
            <Menu className="h-5 w-5" />
          </Button>
        </div>
      </div>
    </header>
  );
}