import { Star, Users, Gauge, Fuel, MapPin, Shield, Award, CheckCircle } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "./ui/dialog";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Vehicle } from "./VehicleCard";

interface VehicleDetailsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  vehicle: Vehicle | null;
  onBook: () => void;
}

export function VehicleDetailsDialog({ 
  open, 
  onOpenChange, 
  vehicle,
  onBook 
}: VehicleDetailsDialogProps) {
  if (!vehicle) return null;

  const statusColors = {
    available: 'bg-[#10b981]/20 text-[#10b981] border-[#10b981]/30',
    rented: 'bg-[#f59e0b]/20 text-[#f59e0b] border-[#f59e0b]/30',
    maintenance: 'bg-destructive/20 text-destructive border-destructive/30'
  };

  // Extended vehicle details (can be fetched from API in real implementation)
  const vehicleDetails = {
    description: `The ${vehicle.name} combines luxury, performance, and cutting-edge technology. Perfect for both business and leisure trips, this ${vehicle.type} offers an exceptional driving experience with ${vehicle.type === 'car' ? 'comfortable seating for ' + vehicle.seats + ' passengers' : 'agile handling and fuel efficiency'}. Equipped with modern amenities and safety features, it ensures a smooth and enjoyable journey.`,
    features: [
      'Air Conditioning',
      'Bluetooth Connectivity',
      'GPS Navigation',
      'USB Charging Ports',
      'Premium Sound System',
      'Cruise Control',
      'Parking Sensors',
      'Backup Camera',
      'Keyless Entry',
      'Multi-zone Climate Control'
    ],
    included: [
      'Unlimited Mileage',
      '24/7 Roadside Assistance',
      'Full Insurance Coverage',
      'Free Vehicle Sanitization',
      'Flexible Pickup & Drop-off'
    ],
    specifications: {
      Year: '2024',
      'Engine Type': vehicle.fuelType,
      'Transmission': vehicle.transmission,
      'Fuel Efficiency': vehicle.type === 'bike' ? '45 MPG' : '28 MPG',
      'Luggage Capacity': vehicle.type === 'car' ? '3 Large Bags' : '1 Backpack',
      'Doors': vehicle.type === 'car' ? '4' : 'N/A',
      'Color': 'Multiple options available'
    },
    location: 'Downtown Hub - 123 Main Street, City Center'
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-4xl border-primary/20 max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-start justify-between">
            <div>
              <DialogTitle className="text-3xl bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
                {vehicle.name}
              </DialogTitle>
              <p className="text-muted-foreground mt-1">{vehicle.brand}</p>
            </div>
            <Badge className={statusColors[vehicle.status]}>
              {vehicle.status.charAt(0).toUpperCase() + vehicle.status.slice(1)}
            </Badge>
          </div>
        </DialogHeader>

        <div className="space-y-6 mt-4">
          {/* Image Gallery */}
          <div className="relative h-64 sm:h-80 rounded-lg overflow-hidden bg-muted">
            <img
              src={vehicle.image}
              alt={vehicle.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-4 left-4 flex items-center gap-2 bg-background/90 backdrop-blur px-3 py-2 rounded-full">
              <Star className="h-5 w-5 fill-[#fbbf24] text-[#fbbf24]" />
              <span className="font-semibold">{vehicle.rating}</span>
              <span className="text-sm text-muted-foreground">(128 reviews)</span>
            </div>
          </div>

          {/* Price & Quick Stats */}
          <div className="flex items-center justify-between p-4 rounded-lg bg-gradient-to-br from-[#7c3aed]/10 to-[#ec4899]/10 border border-primary/20">
            <div className="flex items-baseline gap-2">
              <span className="text-4xl font-bold bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
                ₹{vehicle.pricePerDay}
              </span>
              <span className="text-muted-foreground">/day</span>
            </div>
            <div className="flex gap-4">
              {vehicle.type === 'car' && (
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Users className="h-5 w-5" />
                  <span>{vehicle.seats} Seats</span>
                </div>
              )}
              <div className="flex items-center gap-2 text-muted-foreground">
                <Gauge className="h-5 w-5" />
                <span>{vehicle.transmission}</span>
              </div>
              <div className="flex items-center gap-2 text-muted-foreground">
                <Fuel className="h-5 w-5" />
                <span>{vehicle.fuelType}</span>
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-3">
            <h3 className="text-xl font-semibold">Description</h3>
            <p className="text-muted-foreground leading-relaxed">
              {vehicleDetails.description}
            </p>
          </div>

          {/* Vehicle Specifications */}
          <div className="space-y-3">
            <h3 className="text-xl font-semibold">Specifications</h3>
            <div className="grid grid-cols-2 gap-3">
              {Object.entries(vehicleDetails.specifications).map(([key, value]) => (
                <div key={key} className="p-3 rounded-lg bg-muted/50 border border-border/40">
                  <p className="text-xs text-muted-foreground">{key}</p>
                  <p className="font-semibold">{value}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Features */}
          <div className="space-y-3">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              <Award className="h-5 w-5 text-primary" />
              Features & Amenities
            </h3>
            <div className="grid grid-cols-2 gap-2">
              {vehicleDetails.features.map((feature) => (
                <div key={feature} className="flex items-center gap-2 text-sm">
                  <CheckCircle className="h-4 w-4 text-[#10b981]" />
                  <span>{feature}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Included in Rental */}
          <div className="space-y-3">
            <h3 className="text-xl font-semibold flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              What's Included
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {vehicleDetails.included.map((item) => (
                <div key={item} className="p-3 rounded-lg bg-gradient-to-br from-[#10b981]/10 to-transparent border border-[#10b981]/20 flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-[#10b981] shrink-0" />
                  <span className="text-sm font-medium">{item}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Pickup Location */}
          <div className="p-4 rounded-lg bg-muted/50 border border-border/40">
            <h4 className="font-semibold mb-2 flex items-center gap-2">
              <MapPin className="h-5 w-5 text-primary" />
              Pickup Location
            </h4>
            <p className="text-sm text-muted-foreground">{vehicleDetails.location}</p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3 pt-4 sticky bottom-0 bg-background pb-2">
            <Button
              variant="outline"
              className="flex-1"
              onClick={() => onOpenChange(false)}
            >
              Close
            </Button>
            <Button
              className="flex-1 bg-gradient-to-r from-[#7c3aed] to-[#ec4899] hover:opacity-90"
              onClick={() => {
                onOpenChange(false);
                onBook();
              }}
              disabled={vehicle.status !== 'available'}
            >
              {vehicle.status === 'available' ? 'Book Now' : 'Not Available'}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
