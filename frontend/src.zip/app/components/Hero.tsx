import { Search, Calendar, MapPin } from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";

interface HeroProps {
  onSearch: () => void;
}

export function Hero({ onSearch }: HeroProps) {
  return (
    <div className="relative overflow-hidden">
      {/* Gradient Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-[#7c3aed]/20 via-background to-[#ec4899]/20"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(124,58,237,0.15),transparent_50%)]"></div>
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_70%_60%,rgba(236,72,153,0.15),transparent_50%)]"></div>
      
      <div className="relative container px-4 py-20 md:py-32">
        <div className="mx-auto max-w-4xl text-center space-y-8">
          {/* Hero Text */}
          <div className="space-y-4">
            <div className="inline-block">
              <span className="px-4 py-1.5 rounded-full bg-primary/10 border border-primary/20 text-sm text-primary">
                Premium Vehicle Rentals
              </span>
            </div>
            <h1 className="text-4xl md:text-6xl lg:text-7xl tracking-tight bg-gradient-to-r from-white via-white to-white/70 bg-clip-text text-transparent">
              Your Journey Starts With{" "}
              <span className="bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
                Wheelio
              </span>
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
              Rent premium cars and bikes for your next adventure. Flexible pricing, instant booking, and 24/7 support.
            </p>
          </div>

          {/* Search Card */}
          <Card className="p-6 bg-card/50 backdrop-blur border-primary/20">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="relative">
                <MapPin className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  placeholder="Pickup Location"
                  className="pl-10 bg-background/50"
                />
              </div>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  type="date"
                  placeholder="Start Date"
                  className="pl-10 bg-background/50"
                />
              </div>
              <div className="relative">
                <Calendar className="absolute left-3 top-3 h-5 w-5 text-muted-foreground" />
                <Input
                  type="date"
                  placeholder="End Date"
                  className="pl-10 bg-background/50"
                />
              </div>
              <Button
                onClick={onSearch}
                className="bg-gradient-to-r from-[#7c3aed] to-[#ec4899] hover:opacity-90 transition-opacity"
              >
                <Search className="mr-2 h-4 w-4" />
                Search
              </Button>
            </div>
          </Card>

          {/* Stats */}
          <div className="grid grid-cols-3 gap-8 pt-8">
            <div>
              <div className="text-3xl md:text-4xl bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
                500+
              </div>
              <div className="text-sm text-muted-foreground mt-1">Vehicles</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
                50K+
              </div>
              <div className="text-sm text-muted-foreground mt-1">Happy Customers</div>
            </div>
            <div>
              <div className="text-3xl md:text-4xl bg-gradient-to-r from-[#7c3aed] to-[#ec4899] bg-clip-text text-transparent">
                24/7
              </div>
              <div className="text-sm text-muted-foreground mt-1">Support</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
